AS MASALA INDIA — WEBSITE STARTER
=================================

Included:
- index.html — storefront, products, cart and checkout form
- style.css — responsive design for mobile and desktop
- script.js — interactive cart and checkout preview

IMPORTANT:
This is a functional front-end starter, not a live payment-enabled shop.
The cart works in the browser, but online payment is NOT connected. The checkout form
does not transmit or store customer details and does not create a real order.
Do not advertise it as accepting payments until a gateway and secure backend are installed.

Prices are sample display prices per 100 g and must be confirmed before publishing.
Confirm product labels, ingredients, net quantity, FSSAI/licensing details, taxes,
shipping costs, contact email and return policy before accepting public orders.

FREE HOSTING (GitHub Pages):
1. Create/sign in to a GitHub account.
2. Create a new public repository named as-masala-india.
3. Upload index.html, style.css and script.js to the repository root.
4. Open Settings -> Pages; choose Deploy from a branch, select main and /(root), then Save.
5. GitHub will provide a free address like https://YOUR-USERNAME.github.io/as-masala-india/
   (replace YOUR-USERNAME with your GitHub username).

TO ENABLE REAL ONLINE PAYMENTS:
1. Register and complete merchant onboarding with a payment gateway such as Razorpay.
2. Build/deploy a secure backend (for example, a serverless function) to create orders and
   verify payment signatures. Never place secret API keys in browser JavaScript.
3. Connect checkout to the backend and gateway's hosted/secure checkout.
4. Add order storage, confirmation messages, shipping, refund and privacy workflows.
5. Test using the gateway's test mode before going live.

Contact details currently shown:
AS Masala India, Link Road, Samba, Jammu & Kashmir
Phone: +91 90867 07042
Email: asmasalaindia@gmail.com (placeholder — verify or replace before publishing)
