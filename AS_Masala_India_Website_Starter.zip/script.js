const products = [
 {id:"chilli",name:"Red Chilli Powder",emoji:"🌶️",description:"Bold colour and a warming kick for everyday dishes.",price:80,size:"100 g"},
 {id:"turmeric",name:"Turmeric Powder",emoji:"🟡",description:"A golden kitchen staple for curries and dals.",price:70,size:"100 g"},
 {id:"coriander",name:"Coriander Powder",emoji:"🌿",description:"Warm, citrusy flavour for traditional recipes.",price:60,size:"100 g"},
 {id:"jeera",name:"Jeera (Cumin)",emoji:"🌾",description:"Earthy aroma for tempering and seasoning.",price:90,size:"100 g"},
 {id:"garam",name:"Garam Masala",emoji:"🥣",description:"A fragrant spice blend for finishing your favourite dishes.",price:120,size:"100 g"}
];
const cart = {};
const rupees = n => "₹" + n.toLocaleString("en-IN");
const $ = id => document.getElementById(id);
$("year").textContent = new Date().getFullYear();
$("product-grid").innerHTML = products.map(p => `<article class="product-card"><div class="product-art" aria-hidden="true">${p.emoji}</div><h3>${p.name}</h3><p>${p.description}</p><div class="price">${rupees(p.price)} <small>/ ${p.size}</small></div><button data-add="${p.id}">＋ Add to Cart</button></article>`).join("");
function totals(){let count=0,total=0;for(const [id,q] of Object.entries(cart)){const p=products.find(x=>x.id===id);count+=q;total+=p.price*q}return {count,total}}
function renderCart(){
 const {count,total}=totals();$("cart-count").textContent=count;$("cart-total").textContent=rupees(total);$("checkout-total").textContent=rupees(total);
 const entries=Object.entries(cart).filter(([,q])=>q>0);
 $("cart-items").innerHTML=entries.length?entries.map(([id,q])=>{const p=products.find(x=>x.id===id);return `<div class="cart-row"><div><strong>${p.name}</strong><small>${rupees(p.price)} / ${p.size}</small><div class="quantity"><button data-minus="${id}" aria-label="Decrease ${p.name}">−</button><span>${q}</span><button data-plus="${id}" aria-label="Increase ${p.name}">+</button></div></div><strong>${rupees(p.price*q)}</strong></div>`}).join(""):'<p class="empty">Your cart is empty.</p>';
 $("checkout-open").disabled=count===0;$("checkout-open").style.opacity=count===0?".5":"1";
}
$("product-grid").addEventListener("click",e=>{const id=e.target.dataset.add;if(id){cart[id]=(cart[id]||0)+1;renderCart();$("cart-count").animate?.([{transform:"scale(1.3)"},{transform:"scale(1)"}],{duration:250})}});
$("cart-items").addEventListener("click",e=>{const id=e.target.dataset.plus||e.target.dataset.minus;if(!id)return;if(e.target.dataset.plus)cart[id]=(cart[id]||0)+1;else cart[id]=Math.max(0,(cart[id]||0)-1);if(!cart[id])delete cart[id];renderCart()});
function showCart(){ $("overlay").classList.remove("hidden");$("cart-panel").classList.remove("hidden"); }
function hideCart(){ $("overlay").classList.add("hidden");$("cart-panel").classList.add("hidden"); }
$("cart-open").addEventListener("click",showCart);$("cart-close").addEventListener("click",hideCart);$("overlay").addEventListener("click",()=>{hideCart();$("checkout-modal").classList.add("hidden")});
$("checkout-open").addEventListener("click",()=>{if(!totals().count)return;hideCart();$("overlay").classList.remove("hidden");$("checkout-modal").classList.remove("hidden");$("checkout-message").textContent=""});
$("checkout-close").addEventListener("click",()=>{$("checkout-modal").classList.add("hidden");$("overlay").classList.add("hidden")});
$("checkout-form").addEventListener("submit",e=>{e.preventDefault();$("checkout-message").textContent="Checkout preview only. To accept real online payments, connect a payment gateway (such as Razorpay) through a secure backend and configure shipping, tax and order handling. No payment has been taken and no order has been submitted.";});
renderCart();
